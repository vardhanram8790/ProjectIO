import { Routers } from "./Pages/Routes"


function App() {
  return (
    <>
    <Routers />
    </>
  )
}

export default App
